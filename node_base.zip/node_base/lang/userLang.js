var userLang = {
    REGISTSUCCESS:'注册成功',
    VERIFICATION_CODE_ERRO:'验证码无效',
    EMAIL_ERRO:'邮箱无效',
    PASSWORD_NOTUNIFORM:'确认密码不一致',
    PASSWORD_TOO_EASY:'密码强度不够'
}
module.exports=userLang